import bpy
import os
from bpy.props import BoolProperty, IntProperty, EnumProperty, StringProperty, PointerProperty



class FbxExportAnimations(bpy.types.Operator):
	'''Export animations to fbx'''
	bl_idname = "export.fbx_export_animations"
	bl_label = "Export animations to fbx"
	bl_description = 'Export animations to fbx.'
	
	export_file = StringProperty()
	presetpath = StringProperty()
	symmetry_file = StringProperty()
	
	def execute(self, context):
		# export to ...\_exported\animations
		for action in bpy.data.actions:
			print("%s:\t%s" % (action.name, action.EX_export_this))
		
		return {'FINISHED'}


def register():
	bpy.utils.register_class(FbxExportAnimations)
	
	pass

def unregister():
	bpy.utils.unregister_class(FbxExportAnimations)
	
	pass	

if __name__ == "__main__":
	register()