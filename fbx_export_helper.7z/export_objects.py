import bpy
import os
from bpy.props import BoolProperty, IntProperty, EnumProperty, StringProperty, PointerProperty

from . import functions

# TODO: выводить лог (галочка в гуи) с количеством и наименованием проэкспорченнымх материалов (в порядке) и т.д.
# полохо переносятся иерархии объектов с дамми
# попробывать отделять объекты по материалами (один объект - один материал) bpy.ops.mesh.separate(type='MATERIAL')
# детектить колижены (объеденять их по названиям или иерархии с нужным названием, коллапсить в один ?)
# как экспортить альфа вертекс колор, доработать экспорт под это
# при экспорте с отрицательным скейлом инвертится фейсы у геометрии в обратную сторону

# экспортить модели разбитые по материалам с одинаковами пивотами по разным файлам (для зданий со многими материалами для уменьшения дравколов)

# Отбрасывать модификаторы мультирез и пр. аналоги (настройка галочкой)
#	+-- Ловить исключения и восстанавливать анду
# В экспортёре не при каких условиях не экспортить объекты с префиксом TMP_
# при экспорте с выключенным экспорт хидден обжектс странный экспорт как будто ничего не экспортится

	
class FakeOp:
	def report(self, tp, msg):
		print("%s: %s" % (tp, msg))

#===========================================================================
# Custom exception class
#===========================================================================
class Error( Exception ):

	def __init__(self, message):
		self.message = message


class FbxExportObjects(bpy.types.Operator):
	'''Export objects to fbx'''
	bl_idname = "export.fbx_export_objects"
	bl_label = "Export objects to fbx"
	bl_description = 'Export geometry to fbx.'
	
	export_name = StringProperty()
	export_file = StringProperty()
	presetpath = StringProperty()
	symmetry_file = StringProperty()
	
	
	# fbx exporter settings
	def LoadFbxSettings(self, presetpath, preset):
		kwargs = {}
		
		#presetpath = bpy.context.scene.fbx_helper_settings.presetpath
	
		filename = os.path.join(presetpath, preset)
	
		if (os.path.exists(filename)):
			file = open(filename)
			for line in file:
				s = line.replace(' ', '').replace('\n', '').split('=')
			
				kwargs[s[0]] = eval(s[1])
			
			file.close()
		else:
			self.report({'ERROR'},"Not found preset file: " + filename)
			
		return kwargs
	
	
	def execute(self, context):
		#print("\n\n\n#######################################")
		
		fbx_helper = bpy.context.scene.fbx_helper_settings
		
		try:
			import io_scene_fbx.export_fbx
			import io_scene_fbx.export_fbx_bin
		except:
			self.report({'ERROR'},"Could not load required io_scene_fbx.export_fbx.")
			return {'CANCELLED'}
		
		try:
			# turn off undo
			undo = bpy.context.user_preferences.edit.use_global_undo
			bpy.context.user_preferences.edit.use_global_undo = False
			
			if (bpy.context.mode != 'OBJECT'):
				bpy.ops.object.mode_set(mode='OBJECT')
			
			cur_scene = bpy.context.scene
			
			# collect temp objects.
			#temp_objects = functions.CollectTempObjectsByMat(fbx_helper, cur_scene, self.export_name)
			temp_objects = functions.CollectTempObjects(fbx_helper, cur_scene, self.export_name)
			
			# create new scene.
			bpy.ops.scene.new(type='NEW')
			temp_scene = bpy.data.scenes[len(bpy.data.scenes) - 1]
			temp_scene.name = "temp_scene"
			#temp_scene.render.engine = 'CYCLES'
			
			bpy.context.screen.scene = temp_scene
			
			#-------------------------------------------------
			# prepare objects
			for obj in temp_objects:
				if (obj.type != 'MESH' and obj.type != 'CURVE'):
					continue
				
				# sampling object to array
				new_mesh = obj.to_mesh(temp_scene, True, 'PREVIEW')
				new_obj = bpy.data.objects.new(obj.name, new_mesh)
				
				#
				temp_scene.objects.link(new_obj)
				
				# Copy transform
				#matrix = obj.matrix_world.copy()
				#new_obj.matrix_world = matrix
				new_obj.location = obj.location
				new_obj.rotation_euler = obj.rotation_euler
				new_obj.scale = obj.scale
				
				#new_obj.select = True
				#temp_scene.objects.active = new_obj
				#new_obj.data.update()
			
			bpy.context.screen.scene = temp_scene
			temp_scene.update()
			
			
			# merge collisions
			# FAKE
			#for obj in temp_scene.objects:
			#	obj.hide_select = True
			#	obj.hide = True
			#functions.Collapse_collisions(temp_scene, self.export_name)
			
			# Sinchronize all objects
			functions.SincAllObjects(temp_scene)
			
			#-------------------------------------------------
			# merge geometry in one mesh.
			if (fbx_helper.merge_all_geometry):
				# FAKE
				for obj in temp_scene.objects:
					obj.hide_select = True
					obj.hide = True
				functions.Collapse_objects(temp_scene, self.export_name)
				
				obj = temp_scene.objects.active
				
				#-------------------------------------------------
				# materials
				# assign face to material id
				#for face in mesh.tessfaces:
					#me_ob.faces[face.index].material_index = face.material_index
				
				# delete assigned active texture
				#hasattr(bpy.context.object.data, 'uv_textures')
				if (obj.data.uv_textures.active):
					uv_faces = obj.data.uv_textures.active.data
					for uf in uv_faces:
						uf.image = None
				
				if (fbx_helper.ignore_materials):
					# override materials
					functions.create_default_material(obj)
				
				# uvs
				if (fbx_helper.export_uv_type == 'UV_0'):
					# delete all uv maps
					functions.delete_all_uvs(obj)
				
				if (fbx_helper.export_uv_type == 'UV_1'):
					# single uv
					functions.delete_uvs_except_first(obj)
				
				if (fbx_helper.export_uv_type == 'UV_3'):
					functions.uvs_rearrange(obj, uvs_order = ["UVMap", "UVMap_Decal", "UVMap_DecalAlpha"])
				
				if (fbx_helper.export_uv_type == 'UV_4'):
					functions.uvs_rearrange(obj, uvs_order = ["UVMap", "UVMap_Decal", "UVMap_DecalAlpha", "UVMap_Atlas"])
				
				# collapse or remove vertex color.
				if (fbx_helper.ignore_vertexcolor):
					v_cols = obj.data.vertex_colors.keys().copy()
					for c in v_cols:
						c_layer = obj.data.vertex_colors[c]
						obj.data.vertex_colors.remove(c_layer)
				else:
					functions.Collapse_vc_layers(obj)
				
				# add triangulate modifier
				bpy.ops.object.modifier_add(type='TRIANGULATE')
				#-------------------------------------------------
				
			
			# unhide all
			for obj in temp_scene.objects:
				obj.hide_select = False
				obj.hide = False
				
			bpy.ops.object.select_all(action='DESELECT')
			bpy.ops.object.select_all(action='TOGGLE')
			
			# reset transform
			bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
			
			if (fbx_helper.debug_skip_export):
				# restore pre operator undo state
				bpy.context.user_preferences.edit.use_global_undo = undo
				return {'CANCELLED'}
			
			# export
			
			# exporter settings
			#kwargs = self.LoadFbxSettings(self.presetpath, "fbx_ue_preset.py")
			#kwargs = self.LoadFbxSettings(self.presetpath, "fbx_ue_bin_all_meshes_preset.py")
			#kwargs = self.LoadFbxSettings(self.presetpath, "fbx_ue_test.py")
			kwargs = self.LoadFbxSettings(self.presetpath, "fbx_ue_test275.py")
			#print(kwargs)
			
			try:
				# create folder if not exist
				if (not (os.path.exists( os.path.dirname(self.export_file) ))):
					os.makedirs( os.path.dirname(self.export_file) )
			except:
				self.report({'ERROR'},"Dont created path for export.")
				return {'CANCELLED'}
			
			bpy.ops.export_scene.fbx(filepath = self.export_file, **kwargs)
			
			# TODO: arguments not working
			# if (kwargs["version"].startswith("BIN")):
				# # export binary version
				# io_scene_fbx.export_fbx_bin.save(FakeOp(), bpy.context, self.export_file, **kwargs)
			# else:
				# # export ascii version
				# io_scene_fbx.export_fbx.save(FakeOp(), bpy.context, self.export_file, **kwargs)
				# #io_scene_fbx.export_fbx.save_single(FakeOp(), temp_scene, self.export_file, **kwargs) # ERRORS!!!!
			
			
			if (fbx_helper.is_export_symmetry):
				# copy file to sym location
				import shutil
				if (not (os.path.exists( os.path.dirname(self.symmetry_file) ))):
					os.makedirs( os.path.dirname(self.symmetry_file) )
				
				if (os.path.exists(self.export_file)):
					shutil.copyfile(self.export_file, self.symmetry_file)
			
			#return {'CANCELLED'}
			
			# delete all from temp scene
			functions.CleanScene(temp_scene)
			
			bpy.context.screen.scene = cur_scene
			
			# delete temp scene
			temp_scene.user_clear()
			bpy.data.scenes.remove(temp_scene)
			
			#mat.user_clear()
			#bpy.data.materials.remove(mat)
			#UseMaterialNodes(obj, True)
			
			# restore pre operator undo state
			bpy.context.user_preferences.edit.use_global_undo = undo


			return {'FINISHED'}
			
		#except:
		except Error as err:
			print(err.message)
			#self.report({'ERROR'},"Export error.")
			# restore scene
			#self.CleanScene(temp_scene, cur_scene)
			
			# restore pre operator undo state
			bpy.context.user_preferences.edit.use_global_undo = undo
			return {'CANCELLED'}

		

def register():
	bpy.utils.register_class(FbxExportObjects)
	
	pass

def unregister():
	bpy.utils.unregister_class(FbxExportObjects)
	
	pass

if __name__ == "__main__":
	register()




