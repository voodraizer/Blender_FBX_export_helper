import bpy
import os
from bpy.props import BoolProperty, IntProperty, EnumProperty, StringProperty, PointerProperty


	
def GetExportPath():
	projects = []
	
	#fbx_h = bpy.data.worlds[0].fbx_helper_settings
	#presetpath = fbx_h.presetpath
	#presetpath = "c:\\Users\\voodoo\\AppData\\Roaming\\Blender Foundation\\Blender\\2.74\\scripts\\addons\\fbx_export_helper\\settings"
	presetpath = os.path.join(os.path.dirname(__file__), 'settings')
	
	filename = os.path.join(presetpath, "projects.py")
	
	if (os.path.exists(filename)):
		file = open(filename)
		for line in file:
			if (line.startswith("#")):
			#if (line.count("#") > 0):
				continue
			
			val = eval(line)
			projects.append( (val[0], val[1], '') )
			
		file.close()
	else:
		#self.report({'ERROR'},"Not found preset file: " + filename)
		pass
	
	return projects


class FbxHelper(bpy.types.PropertyGroup):
	
	# # full path to exported file
	# def set_export_file(self, value):
		# #print("SETTING ###################################################")
		# self['export_file'] = value # OK !!!!
		# #self.export_file = value # ERROR!!! Recursia
		# pass
		
	# def get_export_file(self):
		# #return self.get('export_file')
		# return self['export_file'] # OK !!!!!
		# #return self.export_file # ERROR!!! Recursia
		# #return FbxHelper.get(FbxHelper.export_file)
	
	# export_file = StringProperty(get = get_export_file, set = set_export_file)
	
	merge_all_geometry = BoolProperty(default = True)
	
	# export_file_symmetry = StringProperty()
	
	# export in symmetry folder
	is_export_symmetry = BoolProperty(default = False)
	
	# ignore object material
	ignore_materials = BoolProperty(default = False)
	sort_materials = BoolProperty(default = False)
	# 
	ignore_uvs = BoolProperty(default = False)
	use_only_first_uv = BoolProperty(default = False)
	#
	ignore_vertexcolor = BoolProperty(default = False)
	# path to presets directory
	#presetpath = StringProperty()
	
	# 
	export_hidden = BoolProperty(default = True)
	export_freeze = BoolProperty(default = True)
	
	export_colliders = BoolProperty(default = True)
	
	# animations
	only_current_anim = BoolProperty(default = True)
	use_armature_name_in_anim = BoolProperty(default = True)
	use_folder_for_each_armature = BoolProperty(default = True)
	
	#
	export_type = EnumProperty(items = [('OBJECTS', 'Objects', ''),('ANIMATIONS', 'Animations', '')],
		name = 'Export type',
		description = '',
		default = 'OBJECTS'
		)
	
	export_uv_type = EnumProperty(items = [	('UV_0', 'No UVs', ''),
											('UV_1', 'Single UV', ''),
											('UV_2', 'All UVs (as is)', ''),
											('UV_3', '1-UVMap   2-UVMap_Decal   3-UVMap_DecalAlpha', ''),
											('UV_4', '1-UVMap   2-UVMap_Decal   3-UVMap_DecalAlpha   4-UVMap_Atlas', '')],
		name = 'Export UV type',
		description = '',
		default = 'UV_1'
		)
		
	# projects path
	projects = GetExportPath()
	
	#project = EnumProperty(items = [],
	project = EnumProperty(items = projects,
		default = ''
		)
	
	display_geometry = BoolProperty(default = False)
	display_uv = BoolProperty(default = False)
	display_check = BoolProperty(default = False)
	
	
	debug_skip_export = BoolProperty(default = False)


def register():
	#bpy.utils.register_module(__name__)
	
	bpy.utils.register_class(FbxHelper)
	bpy.types.Scene.fbx_helper_settings = PointerProperty(type = FbxHelper)
	
	# Allow change in draw. Need test. Ref bpy.context.window_manager.katietools
	#bpy.types.WindowManager.some_string = bpy.props.StringProperty(name="Some String")
	#context.window_manager.some_string = 'dfsdfd22'
	

	# TEST.
	#fbx_h = bpy.context.scene.fbx_helper_settings
	#fbx_h.presetpath = "c:\\Users\\voodoo\\AppData\\Roaming\\Blender Foundation\\Blender\\2.73\\scripts\\addons\\fbx_export_helper\\settings"
	
	pass

def unregister():
	try:
		del bpy.types.Scene.fbx_helper_settings
	except:
		pass
	
	bpy.utils.unregister_class(FbxHelper)
	
	#bpy.utils.unregister_module(__name__)
	pass	

if __name__ == "__main__":
	register()
