import bpy
from bpy.types import Menu, Panel, Operator
from bpy.props import BoolProperty, IntProperty, EnumProperty, StringProperty, PointerProperty
from bl_operators.presets import AddPresetBase




class AddFbxHelperPreset(AddPresetBase, Operator):
	bl_idname = "scene.fbx_helper_preset_add"
	bl_label = "Add Preset"
	preset_menu = "Fbx_helper_presets"

	preset_defines = [
		"fbx_helper = bpy.context.scene.fbx_helper_settings"
	]

	preset_subdir = "fbx_export_helper"

	use_focal_length = BoolProperty(
			name="Include Focal Length",
			description="Include focal length into the preset",
			options={'SKIP_SAVE'},
			default=True
			)

	@property
	def preset_values(self):
		preset_values = [
			"fbx_helper.is_export_symmetry",
			"fbx_helper.export_hidden",
			"fbx_helper.export_freeze",
			"fbx_helper.export_colliders"
		]
		if (self.use_focal_length):
			#preset_values.append("camera.units")
			#preset_values.append("camera.focal_length")
			pass
		
		return preset_values



class FbxHelper_presets(Menu):
	bl_label = "Presets"
	preset_subdir = "fbx_helper"
	preset_operator = "script.execute_preset"
	draw = Menu.draw_preset



def LoadLastSettings():
	#fbx_helper = bpy.data.worlds[0].fbx_helper_settings
	
	#fbx_helper.is_export_symmetry = True
	#fbx_helper.presetpath = "c:\\Users\\voodoo\\AppData\\Roaming\\Blender Foundation\\Blender\\2.73\\scripts\\addons\\fbx_export_helper\\settings"
	
	pass




def register():
	#bpy.utils.register_module(__name__)
	
	bpy.utils.register_class(AddFbxHelperPreset)
	bpy.utils.register_class(FbxHelper_presets)
	pass

def unregister():
	bpy.utils.unregister_class(AddFbxHelperPreset)
	bpy.utils.unregister_class(FbxHelper_presets)
	
	#bpy.utils.unregister_module(__name__)
	pass

if __name__ == "__main__":
    register()