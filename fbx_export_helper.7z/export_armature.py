import bpy
import os
from bpy.props import BoolProperty, IntProperty, EnumProperty, StringProperty, PointerProperty



class FbxExportArmature(bpy.types.Operator):
	'''Export armature to fbx'''
	bl_idname = "export.fbx_export_armature"
	bl_label = "Export armature to fbx"
	bl_description = 'Export armature to fbx.'
	
	export_file = StringProperty()
	presetpath = StringProperty()
	symmetry_file = StringProperty()
	
	def execute(self, context):
		# export to ...\_exported\animations
		#for action in bpy.data.actions:
		#	print("%s:\t%s" % (action.name, action.EX_export_this))
		armObj = functions.FindArmatureObject()
		if (armObj != None):
			
			pass
		
		return {'FINISHED'}


def register():
	bpy.utils.register_class(FbxExportArmature)
	
	pass

def unregister():
	bpy.utils.unregister_class(FbxExportArmature)
	
	pass	

if __name__ == "__main__":
	register()