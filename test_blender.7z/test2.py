print("======")
    


def PackColl_old(col):
    tmpcollect = []
    for i in range(1, len(col)-1):
        if (i==1):
            tmpcollect = [col[i-1], col[i]]
        else:
            tmpcollect = [tmpcollect, col[i]]
        tmpcollect.reverse()
    
    tmpcollect = [col[len(col)-1], tmpcollect]
        
    return tmpcollect

def PackColl(col):
    tmpcollect = [col[1], col[0]]
    for i in range(2, len(col)-1):
        tmpcollect = [tmpcollect, col[i]]
        tmpcollect.reverse()
    
    tmpcollect = [col[len(col)-1], tmpcollect]
        
    return tmpcollect

coll_3 = ["col_3_3","col_3_2","col_3_1","col_3"]

coll_2 = ["col_2_4","col_2_3","col_2_2","col_2_1","col_2"]

coll_1 = ["col_2"]
coll_0 = ["col_3"]


print(PackColl(coll_2))



