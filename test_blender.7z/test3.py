print("======")
    


def PackColl(col):
    length = len(col)
    
    if (length ==1):
        return [col[0], ""]
    if (length <=2):
        return [col[1], col[0]]
        
    tmpcollect = [col[1], col[0]]
    for i in range(2, length - 1):
        tmpcollect = [tmpcollect, col[i]]
        tmpcollect.reverse()
    
    tmpcollect = [col[length - 1], tmpcollect]
        
    return tmpcollect

coll_3 = ["col_3_3","col_3_2","col_3_1","col_3"]
coll_2 = ["col_2_4","col_2_3","col_2_2","col_2_1","col_2"]
coll_1 = ["col_1_1", "col_1"]
coll_0 = ["col_0"]


print(PackColl(coll_2))




